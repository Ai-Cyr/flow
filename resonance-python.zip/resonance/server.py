#!/usr/bin/env python3
"""Serve Résonance and relay its fixed API route, using Python only."""

import argparse
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import ipaddress
import json
from pathlib import Path
import re
import socket
import sys
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, unquote, urlencode, urlsplit, urlunsplit
from urllib.request import HTTPRedirectHandler, ProxyHandler, Request, build_opener


DEFAULT_API_URL = "http://127.0.0.1:5001/api/data"
MAX_RESPONSE = 5_000_000
MIME_TYPES = {
    ".html": "text/html; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".svg": "image/svg+xml",
    ".json": "application/json; charset=utf-8",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".webp": "image/webp",
    ".ico": "image/x-icon",
    ".woff": "font/woff",
    ".woff2": "font/woff2",
    ".ttf": "font/ttf",
}


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def validate_api_url(value):
    parts = urlsplit(value)
    if parts.scheme not in ("http", "https") or not parts.hostname:
        raise ValueError("L’adresse API doit commencer par http:// ou https://.")
    if parts.username or parts.password or parts.query or parts.fragment:
        raise ValueError("L’adresse API ne doit contenir ni identifiant, ni paramètres, ni fragment.")
    try:
        parts.port
    except ValueError as exc:
        raise ValueError("Le port de l’API est invalide.") from exc
    return urlunsplit((parts.scheme, parts.netloc, parts.path or "/", "", ""))


def birth_query(query):
    if len(query) > 3000:
        raise ValueError("Les paramètres de naissance sont trop longs.")
    try:
        fields = parse_qs(query, keep_blank_values=True, strict_parsing=True, max_num_fields=3)
    except ValueError as exc:
        raise ValueError("Les paramètres de naissance sont invalides.") from exc
    if set(fields) != {"dt_naiss", "ville", "pays"} or any(len(values) != 1 for values in fields.values()):
        raise ValueError("Renseignez une seule fois dt_naiss, ville et pays.")
    result = {key: values[0].strip() for key, values in fields.items()}
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}", result["dt_naiss"]):
        raise ValueError("La date doit suivre le format AAAA-MM-JJTHH:mm:ss.")
    try:
        datetime.strptime(result["dt_naiss"], "%Y-%m-%dT%H:%M:%S")
    except ValueError as exc:
        raise ValueError("La date ou l’heure de naissance est invalide.") from exc
    for key in ("ville", "pays"):
        value = result[key]
        if not value or len(value) > 200 or any(ord(char) < 32 or ord(char) == 127 for char in value):
            raise ValueError("La ville et le pays doivent contenir entre 1 et 200 caractères valides.")
    return urlencode(result)


class ResonanceServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address, handler, api_url, root, timeout=25):
        self.api_url = validate_api_url(api_url)
        self.root = Path(root).resolve()
        self.upstream_timeout = timeout
        self.opener = build_opener(ProxyHandler({}), NoRedirect())
        super().__init__(address, handler)
        host, port = self.server_address[:2]
        names = {address[0].lower(), host.lower()}
        try:
            if ipaddress.ip_address(host).is_loopback:
                names.update(("localhost", "127.0.0.1"))
        except ValueError:
            pass
        # For wildcard binding, only accept this machine's addresses, never an arbitrary Host.
        if host == "0.0.0.0":
            names.update(("localhost", "127.0.0.1", socket.gethostname().lower()))
            try:
                names.update(socket.gethostbyname_ex(socket.gethostname())[2])
            except OSError:
                pass
            names.discard("0.0.0.0")
        self.authorities = {f"{name}:{port}" for name in names}
        if port == 80:
            self.authorities.update(names)


class ResonanceHandler(BaseHTTPRequestHandler):
    server_version = "ResonancePython/1.0"

    def log_message(self, format_string, *args):
        # Birth dates and locations must not be written to HTTP access logs.
        path = urlsplit(self.path).path
        sys.stderr.write(f"{self.command} {path}\n")

    def reply(self, status, body, content_type="application/json; charset=utf-8"):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.end_headers()
        if self.command != "HEAD":
            try:
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError):
                pass

    def error(self, status, message):
        self.reply(status, json.dumps({"status": "error", "message": message}, ensure_ascii=False).encode("utf-8"))

    def trusted_request(self):
        authority = self.headers.get("Host", "").lower()
        if authority not in self.server.authorities:
            self.error(403, "L’adresse utilisée pour joindre cette interface n’est pas autorisée.")
            return False
        if urlsplit(self.path).path != "/api/data":
            return True
        origin = self.headers.get("Origin")
        if origin:
            parsed = urlsplit(origin)
            if parsed.scheme != "http" or parsed.netloc.lower() != authority or parsed.path or parsed.query or parsed.fragment:
                self.error(403, "Cette requête doit provenir de l’interface Résonance sur ce serveur.")
                return False
        if self.headers.get("Sec-Fetch-Site", "") == "cross-site":
            self.error(403, "Les requêtes depuis un autre site ne sont pas autorisées.")
            return False
        return True

    def do_HEAD(self):
        self.do_GET()

    def do_POST(self):
        self.error(405, "Seules les requêtes GET sont acceptées.")

    do_PUT = do_POST
    do_PATCH = do_POST
    do_DELETE = do_POST
    do_OPTIONS = do_POST

    def do_GET(self):
        if not self.trusted_request():
            return
        try:
            parsed = urlsplit(self.path)
        except ValueError:
            self.error(400, "Adresse de requête invalide.")
            return
        if parsed.scheme or parsed.netloc or parsed.fragment:
            self.error(400, "Adresse de requête invalide.")
            return
        if parsed.path == "/api/data":
            if self.command != "GET":
                self.error(405, "Le calcul utilise uniquement GET.")
                return
            self.proxy_chart(parsed.query)
            return
        if parsed.path == "/runtime-config.js":
            self.reply(200, b"export const API_ENDPOINT = '/api/data';\nexport const API_MODE = 'proxy';\n", "text/javascript; charset=utf-8")
            return
        try:
            path = unquote(parsed.path, errors="strict")
            if "\x00" in path or "\\" in path or any(part.startswith(".") for part in path.split("/") if part):
                raise ValueError("Invalid path")
            file = (self.server.root / (path.lstrip("/") or "index.html")).resolve()
            if not file.is_relative_to(self.server.root) or not file.is_file() or file.suffix.lower() not in MIME_TYPES:
                raise ValueError("Not a public file")
            self.reply(200, file.read_bytes(), MIME_TYPES[file.suffix.lower()])
        except (ValueError, UnicodeError, OSError):
            self.error(404, "Ressource introuvable.")

    def proxy_chart(self, query):
        try:
            encoded = birth_query(query)
        except ValueError as exc:
            self.error(400, str(exc))
            return
        request = Request(self.server.api_url + "?" + encoded, headers={"Accept": "application/json, image/svg+xml"}, method="GET")
        try:
            response = self.server.opener.open(request, timeout=self.server.upstream_timeout)
        except HTTPError as exc:
            response = exc
        except (TimeoutError, socket.timeout):
            self.error(504, "L’API met trop de temps à répondre. Vérifiez le serveur de calcul.")
            return
        except URLError as exc:
            if isinstance(exc.reason, (TimeoutError, socket.timeout)):
                self.error(504, "L’API met trop de temps à répondre. Vérifiez le serveur de calcul.")
            else:
                self.error(502, "Le serveur de l’interface ne peut pas joindre l’API. Démarrez le service de calcul ou vérifiez l’option --api-url du lanceur Python.")
            return
        except OSError:
            self.error(502, "Le serveur de l’interface ne peut pas joindre l’API. Démarrez le service de calcul ou vérifiez l’option --api-url du lanceur Python.")
            return
        try:
            with response:
                if 300 <= response.status < 400:
                    self.error(502, "L’API redirige la requête. Renseignez son adresse finale avec --api-url.")
                    return
                data = response.read(MAX_RESPONSE + 1)
                if len(data) > MAX_RESPONSE:
                    self.error(502, "La réponse de l’API dépasse la taille maximale autorisée.")
                    return
                content_type = response.headers.get_content_type()
                if content_type not in ("application/json", "image/svg+xml"):
                    if response.status >= 400:
                        self.error(response.status, f"Le service de calcul a renvoyé une erreur {response.status}.")
                    else:
                        self.error(502, "L’API n’a renvoyé ni données JSON ni schéma SVG.")
                    return
                self.reply(response.status, data, content_type + "; charset=utf-8")
        except (TimeoutError, socket.timeout):
            self.error(504, "La réponse de l’API a pris trop de temps.")
        except (URLError, OSError):
            self.error(502, "La connexion à l’API a été interrompue.")


def create_server(host="127.0.0.1", port=4173, api_url=DEFAULT_API_URL, root=None, timeout=25):
    return ResonanceServer((host, port), ResonanceHandler, api_url, root or Path(__file__).parent / "dist", timeout)


def main():
    parser = argparse.ArgumentParser(description="Lancer Résonance avec Python, sans Node.js et sans réglage CORS de l’API.")
    parser.add_argument("--host", default="127.0.0.1", help="Adresse d’écoute ; utiliser l’IP privée du serveur pour un accès réseau.")
    parser.add_argument("--port", type=int, default=4173, help="Port de l’interface (4173 par défaut).")
    parser.add_argument("--api-url", default=DEFAULT_API_URL, help="Adresse complète du service de calcul, depuis cette machine.")
    args = parser.parse_args()
    if not 1 <= args.port <= 65535:
        parser.error("Le port doit être compris entre 1 et 65535.")
    try:
        server = create_server(args.host, args.port, args.api_url)
    except (ValueError, OSError) as exc:
        parser.exit(1, f"Impossible de démarrer Résonance : {exc}\n")
    print(f"Résonance · http://{args.host}:{args.port}", flush=True)
    print("API reliée par le serveur Python. Ctrl+C pour arrêter.", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
