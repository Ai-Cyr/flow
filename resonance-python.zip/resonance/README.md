# Résonance — interface Design Humain

Interface web en français, inspirée des couleurs de [l’Expérience Vibratoire](https://experiencevibratoire.com/).

## Démarrer

Node.js n’est pas nécessaire. Depuis ce dossier sur la machine de l’API :

```bash
python server.py
```

Sur Linux, utilisez `python3 server.py` si la commande `python` n’existe pas. Le lanceur utilise uniquement la bibliothèque standard de Python. Il sert l’interface sur `http://127.0.0.1:4173` et relaie `/api/data` vers `http://127.0.0.1:5001/api/data`. Le navigateur n’appelle plus directement le port 5001 : aucune configuration CORS n’est nécessaire pour cette connexion.

La connexion est détectée automatiquement et les anciennes adresses conservées dans le navigateur sont ignorées dans ce mode. Votre API doit toujours être démarrée séparément.

### API et interface sur un VPS, navigateur via SSH

Sur le VPS, arrêtez l’ancien serveur d’interface sur 4173 (`Ctrl+C` dans son terminal), laissez l’API sur 5001 en marche, puis lancez `python3 server.py` depuis ce dossier.

Sur votre ordinateur, conservez le tunnel SSH déjà existant si le port 4173 est redirigé. Pour en créer un :

```bash
ssh -N -L 4173:127.0.0.1:4173 utilisateur@votre-vps
```

Ouvrez ensuite `http://localhost:4173` et rechargez la page. Le port 5001 peut rester redirigé, mais n’est plus nécessaire pour l’interface. Aucun port public du VPS n’a besoin d’être ouvert pour ce lancement.

Si la route réelle de votre API diffère de `/api/data`, configurez-la explicitement au démarrage :

```bash
python3 server.py --api-url http://127.0.0.1:5001/votre-route
```

La route actuelle `/api/data` a été confirmée pour votre backend.

### Interface statique ou version en ligne

Le dossier `dist/` peut aussi être servi par `npm start` (Node.js) ou `python -m http.server 4173 --directory dist --bind 127.0.0.1`. Ces serveurs statiques n’incluent pas le relais : les appels partent directement du navigateur et l’API doit alors autoriser l’origine de l’interface via CORS. La version publiée en ligne utilise également ce mode direct.

## Connecter l’API

L’adresse par défaut correspond à votre route actuelle : `http://localhost:5001/api/data`. En mode direct, `localhost` désigne la machine du navigateur, ou un port redirigé localement par SSH. Pour une API sur une autre machine sans tunnel, utilisez son adresse réseau. L’URL est modifiable dans les paramètres en mode direct ; avec le lanceur Python, elle se règle sur le serveur via `--api-url`.

La requête est un `GET`, avec les paramètres `dt_naiss` (ex. `2026-10-16T15:45:00`), `ville` et `pays`. L’heure saisie est transmise telle quelle, sans conversion de fuseau horaire. La résolution du fuseau à partir du lieu relève de l’API.

Le client accepte un SVG brut ou une réponse JSON contenant `svg`. Les champs fournis par l’API sont pris en charge : `Type` / `C_Type`, `Profil`, `Autorite` / `C_Autorite`, `Stratégie`, `Definition`, `Croix`, `Croix_code`, `Com`, `Signature`, `TNS`, `Quartier`, `Sol_Nom`, `Sol_Hexa`, `I_Type` et `I_Autorite`. Les variantes `C_Profil` / `C_Profile`, `C_Strategie` et `C_Definition` sont également acceptées. Les champs explicites `C_*` ont priorité sur les alias génériques du même objet ; les champs `I_*` sont conservés séparément.

Le champ `svg` de l’extrait fourni étant tronqué, son affichage complet reste à confirmer avec la réponse entière du service. Aucun résultat n’est inventé si un champ manque. Une réponse avec `status: "error"` est signalée comme un échec, même si son code HTTP est 200.

Pour un appel direct depuis le navigateur, l’API doit autoriser l’origine de l’interface via CORS. Pour une API hébergée en ligne, utilisez HTTPS. Depuis un site HTTPS, les appels vers un service local peuvent aussi dépendre des permissions et des restrictions du navigateur.

## Vérifier

```bash
python3 -m unittest discover -s tests -p 'test_*.py'
node --test tests/api.test.mjs
```

Les tests vérifient le contrat de requête, les dates et heures, l’extraction des réponses et les erreurs, avec des réponses simulées. Ils ne remplacent pas un test d’intégration avec le service réel.
