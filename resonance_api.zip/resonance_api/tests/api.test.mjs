import test from 'node:test';
import assert from 'node:assert/strict';
import { buildRequestUrl, normalizeResponse, fetchChart } from '../dist/api.js';

const birth = { date: '2026-10-16', time: '15:45', city: 'Paris', country: 'France' };
const endpoint = 'http://localhost:5001/svg-data';
const svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 10 10"><circle cx="5" cy="5" r="4" /></svg>';

test('uses the exact GET parameters from the supplied API example', () => {
  const url = new URL(buildRequestUrl(endpoint, birth));
  assert.equal(url.origin + url.pathname, endpoint);
  assert.deepEqual(Object.fromEntries(url.searchParams), { dt_naiss: '2026-10-16T15:45:00', ville: 'Paris', pays: 'France' });
});

test('preserves seconds and encodes international place names without timezone conversion', () => {
  const url = new URL(buildRequestUrl(endpoint, { ...birth, date: '1992-02-29', time: '03:02:08', city: ' Évry-Courcouronnes ', country: ' Côte d’Ivoire ' }));
  assert.equal(url.searchParams.get('dt_naiss'), '1992-02-29T03:02:08');
  assert.equal(url.searchParams.get('ville'), 'Évry-Courcouronnes');
  assert.equal(url.searchParams.get('pays'), 'Côte d’Ivoire');
});

test('rejects invalid dates, incomplete input and unsafe endpoints before fetching', () => {
  for (const date of ['2026-02-29', '2026-04-31', '2026-13-01', '0000-01-01', '16/10/2026']) {
    assert.throws(() => buildRequestUrl(endpoint, { ...birth, date }), { code: 'validation' });
  }
  for (const time of ['24:00', '12:60', '3:05', '', '12:00:60']) {
    assert.throws(() => buildRequestUrl(endpoint, { ...birth, time }), { code: 'validation' });
  }
  assert.throws(() => buildRequestUrl(endpoint, { ...birth, city: ' ' }), { code: 'validation' });
  for (const url of ['javascript:alert(1)', 'http://example.com/svg-data', 'https://me:secret@example.com/svg-data']) {
    assert.throws(() => buildRequestUrl(url, birth), { code: 'endpoint' });
  }
  for (const url of ['http://127.0.0.1:5001/svg-data', 'http://192.168.1.10:5001/svg-data', 'https://example.com/svg-data']) {
    assert.doesNotThrow(() => buildRequestUrl(url, birth));
  }
});

test('extracts nested SVG and known French metadata without adding invented fields', () => {
  const raw = { data: { chart: { svg_content: svg }, informations: { profil: '2/4', autorité: 'Émotionnelle', stratégie: 'Attendre la réponse', type: 'Générateur' } } };
  const result = normalizeResponse(raw);
  assert.equal(result.raw, raw);
  assert.equal(result.svg, svg);
  assert.deepEqual(result.details, { profile: '2/4', authority: 'Émotionnelle', strategy: 'Attendre la réponse', type: 'Générateur' });
  assert.deepEqual(normalizeResponse({ unexpected: [1, 2, 3] }), { raw: { unexpected: [1, 2, 3] }, svg: null, details: {} });
});

test('extracts plain SVG and handles cyclic input within bounded traversal', () => {
  assert.equal(normalizeResponse(`<?xml version="1.0"?>\n${svg}`).svg, `<?xml version="1.0"?>\n${svg}`);
  const cyclic = { svg }; cyclic.self = cyclic;
  assert.equal(normalizeResponse(cyclic).svg, svg);
});

test('extracts the actual partial API response and preserves root C_Type over generic nested types', () => {
  const raw = {
    Autorite: 'Plexus Solaire',
    C_Autorite: 'Plexus Solaire',
    C_Type: 'Projecteur',
    Com: 'Guide altruiste',
    Croix: "Croix de l’angle droit de Maya 3",
    Croix_code: '(32/42 | 62/61)',
    Definition: 'Double',
    drawing: { type: 'path', svg_data: svg },
  };
  const result = normalizeResponse(raw);
  assert.equal(result.svg, svg);
  assert.deepEqual(result.details, {
    type: 'Projecteur',
    authority: 'Plexus Solaire',
    definition: 'Double',
    incarnationCross: 'Croix de l’angle droit de Maya 3',
    crossGates: '(32/42 | 62/61)',
    description: 'Guide altruiste',
  });
  assert.equal(result.raw, raw);
  assert.equal('profile' in result.details, false);
});

test('prefers explicit C_* metadata independent of property order and supports profile aliases', () => {
  const result = normalizeResponse({
    type: 'unrelated generic type', C_Type: 'Projecteur',
    Autorite: 'generic fallback', C_Autorite: 'Plexus Solaire',
    profil: 'fallback', C_Profil: '4/6',
    strategie: 'fallback', C_Strategie: 'Attendre l’invitation',
    definition: 'fallback', C_Definition: 'Double',
  });
  assert.deepEqual(result.details, {
    type: 'Projecteur', profile: '4/6', authority: 'Plexus Solaire',
    strategy: 'Attendre l’invitation', definition: 'Double',
  });
  assert.equal(normalizeResponse({ C_Profile: '1/3' }).details.profile, '1/3');
});

test('extracts all additional metadata keys supplied by the real API without conflating authorities', () => {
  const raw = {
    Autorite: 'Plexus Solaire', C_Autorite: 'Plexus Solaire', C_Type: 'Projecteur',
    I_Autorite: 'Environnement', I_Type: 'Projecteur',
    Profil: '3/5 Martyr/Hérétique', Quartier: 'Quartier de Dualité',
    Signature: 'La reconnaissance (succés)', Sol_Hexa: 'L’endurance',
    Sol_Nom: '32 - Continuité', Stratégie: "Attendre l'invitation", TNS: 'L’amertume',
    Type: 'Projecteur', dt_naiss: '2026-10-16T15:45:00', pays: 'France', status: 'success', svg,
  };
  const result = normalizeResponse(raw);
  assert.equal(result.svg, svg);
  assert.deepEqual(result.details, {
    type: 'Projecteur', profile: '3/5 Martyr/Hérétique', authority: 'Plexus Solaire',
    strategy: "Attendre l'invitation", signature: 'La reconnaissance (succés)',
    notSelf: 'L’amertume', quarter: 'Quartier de Dualité', sunName: '32 - Continuité',
    sunHexagram: 'L’endurance', unconsciousType: 'Projecteur', unconsciousAuthority: 'Environnement',
  });
});

test('fetch sends the expected request and normalizes JSON or raw SVG responses', async t => {
  t.mock.method(globalThis, 'fetch', async (url, options) => {
    assert.equal(new URL(url).searchParams.get('dt_naiss'), '2026-10-16T15:45:00');
    assert.equal(options.method, 'GET');
    assert.equal(options.credentials, 'omit');
    return new Response(JSON.stringify({ svg, profile: '1/3' }), { headers: { 'Content-Type': 'application/json' } });
  });
  assert.deepEqual((await fetchChart(endpoint, birth)).details, { profile: '1/3' });
  globalThis.fetch.mock.mockImplementation(async () => new Response(svg, { headers: { 'Content-Type': 'image/svg+xml' } }));
  assert.equal((await fetchChart(endpoint, birth)).svg, svg);
});

test('HTTP failures preserve status and display a bounded server message', async t => {
  t.mock.method(globalThis, 'fetch', async () => new Response(JSON.stringify({ error: 'Ville inconnue' }), { status: 422 }));
  await assert.rejects(fetchChart(endpoint, birth), error => error.code === 'http' && error.status === 422 && error.message.includes('Ville inconnue'));
});

test('rejects API error status even with HTTP 200 and never presents an error as a calculated result', async t => {
  t.mock.method(globalThis, 'fetch', async () => new Response(JSON.stringify({ status: 'error', message: 'Lieu de naissance introuvable.' }), { status: 200 }));
  await assert.rejects(fetchChart(endpoint, birth), error => error.code === 'api' && error.status === 200 && error.message.includes('Lieu de naissance introuvable.'));
  globalThis.fetch.mock.mockImplementation(async () => new Response(JSON.stringify({ status: ' ERROR ', svg })));
  await assert.rejects(fetchChart(endpoint, birth), { code: 'api' });
  globalThis.fetch.mock.mockImplementation(async () => new Response(JSON.stringify({ status: 'success', svg })));
  assert.equal((await fetchChart(endpoint, birth)).svg, svg);
});

test('network and invalid response failures are distinguishable', async t => {
  t.mock.method(globalThis, 'fetch', async () => { throw new TypeError('Failed to fetch'); });
  await assert.rejects(fetchChart(endpoint, birth), { code: 'network' });
  globalThis.fetch.mock.mockImplementation(async () => new Response('<html>Proxy error</html>'));
  await assert.rejects(fetchChart(endpoint, birth), { code: 'response' });
  globalThis.fetch.mock.mockImplementation(async () => new Response('null'));
  await assert.rejects(fetchChart(endpoint, birth), { code: 'response' });
});

test('timeout and caller cancellation abort the actual fetch', async t => {
  t.mock.method(globalThis, 'fetch', async (_url, { signal }) => new Promise((resolve, reject) => {
    if (signal.aborted) reject(new DOMException('Aborted', 'AbortError'));
    else signal.addEventListener('abort', () => reject(new DOMException('Aborted', 'AbortError')), { once: true });
  }));
  await assert.rejects(fetchChart(endpoint, birth, { timeoutMs: 10 }), { code: 'timeout' });
  const controller = new AbortController();
  controller.abort();
  await assert.rejects(fetchChart(endpoint, birth, { signal: controller.signal }), { code: 'aborted' });
});
