# Résonance — interface Design Humain

Interface web en français, inspirée des couleurs de [l’Expérience Vibratoire](https://experiencevibratoire.com/).

## Démarrer

Depuis ce dossier, lancez le serveur local du projet avec `npm start` (ou `node server.mjs`), puis ouvrez l’adresse indiquée. Le dossier `dist/` contient l’interface statique.

## Connecter l’API

L’adresse par défaut reprend la capture fournie : `http://localhost:5001/svg-data`. Le service doit être démarré séparément sur l’ordinateur qui utilise l’interface. L’URL du service est modifiable dans les paramètres de l’interface.

La requête est un `GET`, avec les paramètres `dt_naiss` (ex. `2026-10-16T15:45:00`), `ville` et `pays`. L’heure saisie est transmise telle quelle, sans conversion de fuseau horaire. La résolution du fuseau à partir du lieu relève de l’API.

Le client accepte un SVG brut ou une réponse JSON contenant `svg`. Les champs fournis par l’API sont pris en charge : `Type` / `C_Type`, `Profil`, `Autorite` / `C_Autorite`, `Stratégie`, `Definition`, `Croix`, `Croix_code`, `Com`, `Signature`, `TNS`, `Quartier`, `Sol_Nom`, `Sol_Hexa`, `I_Type` et `I_Autorite`. Les variantes `C_Profil` / `C_Profile`, `C_Strategie` et `C_Definition` sont également acceptées. Les champs explicites `C_*` ont priorité sur les alias génériques du même objet ; les champs `I_*` sont conservés séparément.

Le champ `svg` de l’extrait fourni étant tronqué, son affichage complet reste à confirmer avec la réponse entière du service. Aucun résultat n’est inventé si un champ manque. Une réponse avec `status: "error"` est signalée comme un échec, même si son code HTTP est 200.

Pour un appel direct depuis le navigateur, l’API doit autoriser l’origine de l’interface via CORS. Pour une API hébergée en ligne, utilisez HTTPS. Depuis un site HTTPS, les appels vers un service local peuvent aussi dépendre des permissions et des restrictions du navigateur.

## Vérifier

`node --test tests/api.test.mjs`

Les tests vérifient le contrat de requête, les dates et heures, l’extraction des réponses et les erreurs, avec des réponses simulées. Ils ne remplacent pas un test d’intégration avec le service réel.
